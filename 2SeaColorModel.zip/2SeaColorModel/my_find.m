function [ix iy]=my_find(X,Y)
threshold=5;
n=length(X);
m=length(Y);
for i=1:n
    for j=1:m
    ixx(i,j)=abs(X(i)-Y(j));
    end
end
[imin imin_pos]=min(ixx);
[jmin jmin_pos]=min(ixx');
i_pos=find(imin<threshold);
j_pos=find(jmin<threshold);
ix=unique(i_pos);
iy=unique(j_pos);

end

