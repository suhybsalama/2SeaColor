%% main
    clear all,
    clearvars -global 
    global theta bbFrac z a_final bb_final  eta_final b_final Rrs_final Q_final
gamma=0.80;
fsky=0.0;%this is for hydrolight fsky= 0.0;
theta=30;
bbFrac=0.0182;
z=[-0.03 -5 -10 -20];
L_1=540;
L_2=640;  
 Q_final=3.25;   
Rrs_Data_file='Rrs_hydrolight.m';   
        

Spectra = load( Rrs_Data_file);

L=Spectra(1,:)';
Measured_Rrs=Spectra(2:end,:)';
nr_Spectra=length(Measured_Rrs);
aw1=load('IOP_water_hydro.m');
aw=aw1(:,2);


       
L_needed=[440 490 550 660];
   

Coef_chla=0.2;
Coef_dom=0.15;
Coef_spm=0.18;
Coef_y=0.5;
Coef_s=0.002;

indx_=indexing(L_needed,L);
indx_440=indx_(1);
indx_490=indx_(2);
indx_550=indx_(3);
if length(indx_)>3
indx_640=indx_(4);
end
%%
for ispectra=1:nr_Spectra;
    iMeasured_Rrs=Measured_Rrs(:,ispectra);
    % approx the phytoplankton absorption-coefficent at 440nm (Lee et al., 1998)
      dummy=0.072*(iMeasured_Rrs(indx_440)./iMeasured_Rrs(indx_550)).^-1.62;
%
a_chla = Coef_chla*dummy; 

a_dg = Coef_dom*dummy;
b_SPM =1./bbFrac.*Coef_spm* aw(indx_640)*iMeasured_Rrs(indx_640); %combination of particles backscattering coefficient + viewing angle + sea state,at 400nm , Lee et al. 1999.
Y = abs(Coef_y*3.44*(1-3.17*exp(-2.01*iMeasured_Rrs(indx_440)/iMeasured_Rrs(indx_490)))); %Y is between the range 0 - 2.5, Lee at al. 1996
%>>%initialization
sy=0.2;
mu=[b_SPM,sy,Y];


[iop(:,ispectra)]=inversion_2SeaColor(iMeasured_Rrs,L,aw,gamma,fsky,mu);
a_optimum(:,ispectra)=a_final;
bb_optimum(:,ispectra)=bb_final;
b_optimum(:,ispectra)=b_final;
eta_optimum(:,ispectra)=eta_final;

end

%%


 
simulation=0;
for i=1:4,ix(i)=find(L==L_needed(i));end

switch Rrs_Data_file
          
   
    case 'Rrs_hydrolight.m'
L_hy=400:10:750;
lambda=find(L_hy==490);
        simulation=1;
        Kd0_hydro=load('Kd0_hydrolight.m');
        Kd0_hydro=Kd0_hydro(2:end,:)';
        
        Kd5_hydro=load('Kd5_hydrolight.m');
        Kd5_hydro=Kd5_hydro(2:end,:)';
        
        
        Kd10_hydro=load('Kd10_hydrolight.m');
        Kd10_hydro=Kd10_hydro(2:end,:)';
        
        Kd20_hydro=load('Kd20_hydrolight.m');
        Kd20_hydro=Kd20_hydro(2:end,:)';
        
        Kd40_hydro=load('Kd40_hydrolight.m');
        Kd40_hydro=Kd40_hydro(2:end,:)';
        ixx=find(Kd0_hydro(lambda,:)>0);
         measured=[Kd0_hydro(lambda,:)' Kd5_hydro(lambda,:)' Kd10_hydro(lambda,:)' Kd20_hydro(lambda,:)'];
        a_k=load('a_hydrolight.m');
        
        bb_k=load('bb_hydrolight.m');
        a_h=interp1(a_k(1,:)',a_k(2:end,:)',L);
        bb_h=interp1(bb_k(1,:)',bb_k(2:end,:)',L);
        
         end
%%


%%note the eta has changed so u need to recompute Kd for the similarity transform  values
transform=1;
for j=1:length(z)
    for ks=1:length(ix)
[Kd(j,ks,:),~,Rrs(ks,:)]=TwoSeaColor(a_optimum(ix(ks),ixx),bb_optimum(ix(ks),ixx), b_optimum(ix(ks),ixx),eta_optimum(ixx),gamma,fsky,theta,z(j),transform);
    end
end 
%%


%%
hold on

%%
error=100-100.*squeeze(Kd(1,2,:))./measured(:,1);
irx=find(abs(error)<100000);
[slope,intercept,R2,MAD]=plot_Fit( measured(irx,:),squeeze(Kd(:,2,irx)),' Kd',z(1:4), 490,'m^{-1}');  

%%
if  simulation;
plot_Fit((a_h(ix,:)),(a_optimum(ix,:)),' a','0', L_needed,'m^{-1}');
plot_Fit((bb_h(ix,:)),(bb_optimum(ix,:)),' bb','0', L_needed,'m^{-1}');
end
%%