%Created by Suhyb Salama* 30-03-2014 @ITC, based on the RSE submitted
%paper:
%Two-Stream Color Model for Water Quality in Inland Lakes: 2SeaColor
% 
% Mhd. Suhyb Salama and Wouter Verhoef
% 
% University of Twente, Faculty of Geo-Information Science and Earth Observation (ITC), 
% Department of Water Resources, 
% P.O. Box 217, 7500 AE Enschede, The Netherlands
% % 
% 
% 
% 
% *Corresponding author: +31534874288; s.salama@utwente.nl
%%||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

%% input: 
%a: total absorption
%bb: total backscattering
%b:scattering 
%eta: fraction of backscattering
%gamma: fraction of peaked sorward scattering
%fsky: fraction of diffuse sky
%theta: sun zenith
%z depth
%varargin: other vars

%% Outputs:
%Kd at diffrenbt depths
%R: irradiance ref at -0
%Rrs: at +0
%%

function [Kd R Rrs Q eta]=TwoSeaColor(a,bb,b_o,eta_o,gamma,fsky,theta,z,transform,varargin)
 

Es=1;  
szap=asin(3*sind(theta)/4);%Under water sun zenith using Snell�s law
    mu=cos(szap);
   if transform
  [b,bf, eta]=Hulst_similarity_transformation(a, b_o,eta_o,bb,gamma);
   else
       b=b_o;bf=(1-eta_o).*b_o;eta=eta_o;
   end
x=bb./a;
%%---------

%%
%--------------------------------------------------
k=(a+b)./mu;% attenuation of direct light for downward flux
kappa=2*(a+b);
% Direct light %% old version
 sp=bf./mu;%forward scattering of direct light for downward flux
 s=bb./mu;%backward scattering of the direct light
 sig=2.*bb;% backscattering of diffuse light
 sigp=2*bf;
%------------------------------------------------------------



%% improved version
%   s=0.5/mu.*(b+mu.*(bb-bf));%backward scattering of the direct light
%    sp=0.5/mu.*(b-mu.*(bb-bf));%forward scattering of direct light for downward flux
%   sig=(3*bb+bf)./2;% backscattering of diffuse light
%  sigp=(bb+3*bf)./2;
%% 
%  %% --------------------------------------------------------------------
alfa=kappa-sigp;
m=sqrt(alfa.^2-sig.^2);%the coefficient in the deferential solution 
%%




rdd=sig./(alfa+m);%infinite reflectance of the medium, i.e. the bi-hemispherical reflectance for infinite optical thickness
%rdd=(alfa-m)./sig;%infinite reflectance of the medium, i.e. the bi-hemispherical reflectance for infinite optical thickness


rsd=(s+sp.*rdd)./(k+m);%the infinite directional-hemispherical reflectance factor for direct sunlight (DHRF) downward

J=(exp(m.*z)-exp(k.*z))./(k-m);%
if abs(k-m) <1e-3
    J=-z.*exp(k.*z);%
end


  %-----------------------------------------------------------------

%% irradiances
Eds0=(1-fsky).*Es;%direct sun flux
Edd0=fsky.*Es;%diffuse sun flux
Eds=Eds0.*exp(z.*k);%down welling direct irradiance
Edd=Edd0.*exp(z.*m)+(sp+sig.*rsd).*J.*Eds0;%%down welling diffuse irradiance
 
Eu=rdd.*Edd+rsd.*Eds;%%total upwelling irradiance

Ed=Edd+Eds;%%%total down welling irradiance
 
%% Attenuation Coefficients of downward light

 
     Kd=((k-sp).*Eds+alfa.*Edd-sig.*Eu)./Ed;
     %%
     
 
 R=Eu./Ed;%beneath the surface water irradiance reflectance
% R1=((1-fsky).*rsd+fsky.*rdd);
% R=R1;
%  if length(R)>1
%      R=R(1);
%  end
 
if isempty(varargin)
   Q=3.25;
      else
    Q=R./cell2mat(varargin(1));
     
 end;

 %----------------------------------------------------------------
Rrs=0.52*R./(Q-1.7*R);

end