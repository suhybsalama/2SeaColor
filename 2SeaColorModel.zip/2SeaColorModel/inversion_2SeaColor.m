function [iop cio]=inversion_2SeaColor(rf,L,aw,gamma,fsky,X_varin)
options1 =optimset('TolFun',1e-6,'MaxFunEvals',10000,'LargeScale','on', 'LevenbergMarquardt','on','MaxIter',10000);





m=length(L);
gamma_=repmat(gamma,1,m);
fsky_=repmat(fsky,1,m);
XX=[L,aw,rf,gamma_',fsky_'];

 lb=     [0                   0      0 ];
 ub= [   100                  2.5    2.5  ];

Setup_model='setup2SeaColor_NO_PARAMETRIZATION';
   [iop,resnorm,residual,exitflag,output,lambda,jacobian] = lsqcurvefit(Setup_model,X_varin,XX,rf,lb,ub,options1);
  [ypred,delta] = nlpredci(Setup_model,XX,iop,residual,real(jacobian),0.05,'on');

 plot(L,rf,'k',L,ypred,'^r',L,ypred+delta,'.-b',L,ypred-delta,'.-c')
 xlabel('\lambda [nm]')
 ylabel('Rra [sr^{-1}]')
 title('2SeaColor fitted spectrum')
 
 legend('Observed','Retrieved','pred upper limit','lower limit')
  
drawnow
end