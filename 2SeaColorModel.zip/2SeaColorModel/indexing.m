function [I]=indexing(A,B);

LB=length(B);
LA=length(A);

 large=LB;
 small=LA;
if LB<LA
large=LA;
small=LB;
dump=A;
A=B;
B=dump;
end

count=0;
for j=1:small
[m ii]=min(abs(A(j)-B));
I(j)=ii+count;
if length(B)>1
B=B(setdiff(1:length(B),ii));
count=count+1;
else
    j=small;
end
end
