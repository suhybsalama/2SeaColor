#created by Suhyb Salama 2008
# from Salama et al (2009) and Salama and Stein 2009
# new update in 2016

import numpy as np

# IOP0: [float,float,float,float,float], w1B: array<float>, Aa: array<array<float>>, aw: array<float>, bbsw: array<float>
# returns array<array<float>>, array<array<float>>


def IOP_parametrization(IOP0,wlB,Aa,aw,bbsw):
    achl440  = IOP0[0]
    adg440   = IOP0[1]
    bbspm440 = IOP0[2]
    s        = IOP0[3]
    y        = IOP0[4]   

    m = len(wlB)
    n = m

    # w1B = w1B.astype(float) # wlB=double(wlB)
    #m=length(C_chla)

    a_dg = adg440*np.exp(-s*(wlB - 440.00))

    ## PAAVEL et al., (2016)	
    # SIOP_chlai=load('SIOP_chla.m')
    # SIOP_chla=interp1(SIOP_chlai(:,1),SIOP_chlai(:,2:end),lambda)
    # A=SIOP_chla(:,1)
    # B=SIOP_chla(:,2)
    #a_chla=repmat(A,1,m)'.*repmat(C_chla,1,n).^(1-repmat(B,1,m)')
    ## Lee parameterization

    a1=Aa[0]
    a2=Aa[1]
    a_chla=(a1+np.log(achl440)*a2)*achl440
    ##

    a = aw+a_dg+a_chla# bulk absorption coefficient.

    bb_spm=bbspm440*(440/wlB)**y

    bb = bbsw + bb_spm # bulk scattering coefficient.

    return a, bb
