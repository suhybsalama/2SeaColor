## Created by Suhyb salama @ ITC 2015

import numpy as np
from math import ceil
import matplotlib.pyplot as plt

from lsqfitgm import lsqfitgm

def plot_hydroFit(measured,derived,lb,ub):

    label=['a_{chla}(440) [m^{-1}]','a_{dg}(440) [m^{-1}]','b_{b,spm} [m^{-1}]','a(440) [m^{-1}]']
    titel=['(a)','(b)','(c)','(d)']
    #xshift=0
    #yshift=40
    var_nr = len(measured)
    num_site = len(measured[0])
    
    m = [None] * var_nr
    b = [None] * var_nr
    rd = [None] * var_nr
    sm = [None] * var_nr
    sb = [None] * var_nr
    R = [None] * var_nr
    MAPE = [None] * var_nr
    rMAD = [None] * var_nr
    MAD = [None] * var_nr
    RMSE = [None] * var_nr
    bias = [None] * var_nr

    for i in range(0, var_nr):
        index=np.nonzero((derived[i]>lb[i]) & (derived[i]<=ub[i]))[0]
        real_site_nr=len(index)
        f=ceil(real_site_nr/num_site*100)/100
        iop_d=(derived[i])[index]
        iop_m=(measured[i])[index]
        m[i],b[i],rd[i],sm[i],sb[i]=lsqfitgm(iop_m,iop_d)  
        R[i]=ceil((rd[i]**2)*100)/100
        dump=iop_d- iop_m
        lrange=max(iop_m)-min(iop_m)#std(iop_m);#
        MAPE[i]=100*np.mean(np.abs(dump)/(iop_m))
        rMAD[i]=100*np.mean(np.abs(dump)/lrange)
        MAD[i]= np.sum(np.abs(dump)/(real_site_nr-2))
        RMSE[i]=np.sqrt(np.sum(dump**2)/(real_site_nr-2))    
        bias[i]=(np.mean(iop_m-iop_d))
        plt.subplot(2,2,i+1)
        plt.title(titel[i])
        #xmin=min([iop_d' iop_m'])
        #xmax=max([iop_d' iop_m'])
        #step=abs(xmax-xmin)/100
        #xshift=95
        #yshift=21  
        #box on,axis('square')
        #axis([xmin,xmax,xmin,xmax])
        #plt.plot(iop_m,iop_d,'MarkerFaceColor',[0.502 0.502 0.502],'Marker','o','LineStyle','none','Color',[0.502 0.502 0.502])
        plt.plot(iop_m,iop_d,'g',marker='.',linestyle='none')
        plt.show(block=False)
        #box on,axis('square')
        #axis([xmin,xmax,xmin,xmax])
        #h=refline(1,0)
        #set(h,'Color',[0 0 0])
        #set(gca,'FontSize',12)
        xtxt='known ' + label[i]
        plt.xlabel(xtxt)
        ytxt='Derived ' + label[i]
        plt.ylabel(ytxt)
        #str=['fr=' num2str(f)]
        #text(xmax-xshift*step,xmin+2.5*yshift*step,str,'FontSize',12) 
        #str=['rMAD=' num2str(rMAD(i)) '[%]']
        #str=['MAPE=' num2str(MAPE(i)) '[%]']
        #str=['MAD=' num2str(round(MAD(i),2)) ' [m^{-1}]']
        ##str=['RMSE=' num2str(RMSE(i)) ' [m^{-1}]'];
        #text(xmax-xshift*step,xmin+3*yshift*step,str,'FontSize',12) 
        #str=['R^2=' num2str(R(i))]
        #text(xmax-xshift*step,xmin+3.5*yshift*step,str,'FontSize',12) 
        #str=['Offset =' num2str(round(b(i),2))]
        #text(xmax-xshift*step,xmin+4*yshift*step,str,'FontSize',12)
        #str=['Slope =' num2str(round(m(i),2))]
        #text(xmax-xshift*step,xmin+4.5*yshift*step,str,'FontSize',12) 
        #set(gca,'Position',pos(i,:),'CameraViewAngleMode','Manual','DataAspectRatioMode','Manual', 'PlotBoxAspectRatioMode','Manual','XMinorTick','on','YMinorTick','on','Title',text('String',[titel(i)],'FontSize',12))

    return m,b,R,RMSE,bias,MAPE,rMAD
