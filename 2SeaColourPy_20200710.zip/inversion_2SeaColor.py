
from scipy.optimize import least_squares
from scipy.sparse import block_diag
from numpy import ones
from IOP_parametrization import IOP_parametrization
from Hulst_similarity_transformation import Hulst_similarity_transformation
from TwoSeaColor import TwoSeaColor
from TwoSeaColor_Jacobian import TwoSeaColor_Jacobian

#created by Suhyb Salama March 2020
#this is an update of the old version in 2015

def in_bounds(x,l,u):
    return x[0]>=l[0] and x[0]<=u[0] and \
        x[1]>=l[1] and x[1]<=u[1] and \
        x[2]>=l[2] and x[2]<=u[2] and \
        x[3]>=l[3] and x[3]<=u[3] and \
        x[4]>=l[4] and x[4]<=u[4]


def inversion_2SeaColor(obsR,IOP0,lb,ub,eta0,ingamma,fsky,ta_w,tw_a, wlB,sza_w ,Q,nw,z,A,aw,bbsw):
    Rrs = 0
    R = 0
    Kd = 0

    def computeR(IOP0): #,ed)
        aa,bb= IOP_parametrization(IOP0,wlB,A,aw,bbsw)
        b=bb/eta0
        b, _, eta = Hulst_similarity_transformation(aa,b,eta0,bb,ingamma)
        nonlocal Kd
        nonlocal R
        nonlocal Rrs
        
        Kd, R, Rrs=TwoSeaColor(aa,bb,b,fsky,sza_w,z,Q,ta_w,tw_a,nw)
        Rdiff=(Rrs-obsR)
        return Rdiff



    if not in_bounds(IOP0,lb,ub):
        print('x0="',IOP0,'",lb="',lb,'",ub="',ub,'"')
    nLambda=len(wlB)
    nvar=len(IOP0)
    dum=ones((nLambda),dtype=bool)
    twoDdum=ones((nLambda,nvar),dtype=bool)
    #mJac=TwoSeaColor_Jacobian(IOP0,twoDdum,aw,bbsw,wlB,A[0], A[1],eta0*dum,ingamma*dum,fsky*dum,sza_w,z*dum,Q*dum,ta_w,tw_a,nw)
    jacs_Spar = block_diag([ones((nLambda,nvar), dtype=bool)])
    #IOP = least_squares(computeR,IOP0,bounds=(lb,ub),jac= lambda x:TwoSeaColor_Jacobian(x,twoDdum,aw,bbsw,wlB,A[0], A[1],eta0*dum,ingamma*dum,fsky*dum,sza_w,z*dum,Q*dum,ta_w,tw_a,nw),jac_sparsity=jacs_Spar,loss='soft_l1', f_scale=0.1,ftol=1e-04,max_nfev=100, gtol=1e-04)
    IOP = least_squares(computeR,IOP0,bounds=(lb,ub),jac_sparsity=jacs_Spar,loss='soft_l1', f_scale=0.1,ftol=1e-04,max_nfev=100, gtol=1e-04)
   
    IOP = IOP.x

    return Rrs, R, Kd, IOP
