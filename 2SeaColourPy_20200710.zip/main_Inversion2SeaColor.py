import timeit

start = timeit.default_timer()

from math import radians, exp
import numpy as np
import matplotlib.pyplot as plt

from RIaw import RIaw
from Cox_Munk_BERON import Cox_Munk_BERON
from Snells_Law import Snells_Law
from indexing import indexing
from betasw_ZHH2009 import betasw_ZHH2009
from inversion_2SeaColor import inversion_2SeaColor
from plot_hydroFit import plot_hydroFit

## main
##Created by Suhyb Salama @ITC 2015
##Salama, M. S., & Verhoef, W. (2015). 
##Two-stream remote sensing model for water quality mapping: 2SeaColor.
##Remote sensing of environment, 157, 111-122. https://doi.org/10.1016/j.rse.2014.07.022

## updated 10 of March 2020 for EO4SD-Coastal project

def load(filename):
    result = []
    lines = open(filename, 'r').readlines()
    for line in lines:
        if len(line)>0 and line[0] != '%':
            line = line.split()
            line = [float(s) for s in line]
            result.append(line)
    return np.array(result)

# load column-wise

def load_c(filename):
    result = []
    lines = open(filename, 'r').readlines()
    for line in lines:
        if len(line)>0 and line[0] != '%':
            line = line.split()
            line = [float(s) for s in line]
            if len(result) == 0:
                result = [[f] for f in line]
            else:
                for i in range(0,len(result)):
                    result[i].append(line[i])
    return np.array(result)

def interp1(nx,nny,xx):
    result = np.array([np.interp(xx,nx,ny) for ny in nny])
    return result

#image read

z=[0]
sza=radians(30) # Solar viweing angle: read from the image
vza=radians(42)  # Viewing zenith angle: read from the iamge
saa=radians(0)  #Solar azimuth : read from the image
vaa=radians(90)  #Viewing azimuth : read from the iamge
phi=vaa-saa  #

Rrs_Data_file='Rrs_hydrolight.m' #read from the imgae   
Spectra = load(Rrs_Data_file) #read from the imgae
wlB=Spectra[0] #L=[443,490,560,665,705,740,783,842,865]  #S2 wavelength
Measured_Rrs=Spectra[1:]

##############################################################
nr_Spectra=len(Measured_Rrs) 
#################################

##Water input

Tc=25 # water tempreture 
Q=3.25 # istropic factor
Salinty=30
ws=5 #Wind speed
phi_w=15 # wind direction if possible read

nw, na = RIaw(wlB,Tc,Salinty)
##

ra_w, _, _=Cox_Munk_BERON(ws,phi_w,sza,vza,saa,vaa,na,nw) 
ta_w=1-ra_w

vza_w=Snells_Law(vza,na,nw) 
sza_w=Snells_Law(sza,na,nw) 
rw_a, _, _=Cox_Munk_BERON(ws,phi_w,vza_w,radians(90)-vza,saa,vaa,nw,na)
tw_a=1-rw_a

##

Coef_chla=0.2
Coef_dom=0.15 
Coef_spm=0.018 
Coef_y=0.5
Coef_s=0.002  

L_needed=np.array([443,490,560,665])
indx_=indexing(L_needed,wlB)
indx_440=indx_[0]
indx_490=indx_[1]
indx_550=indx_[2]
if len(indx_)>3:
    indx_640=indx_[3]
eta0=0.0182
s=0.021
ingamma=0.98#0.80
fsky=0#0.5

##
Aa0=load('A_mod.m')
Aa0=Aa0.transpose()
Aa=interp1(Aa0[0],Aa0[1:],wlB)
AWi=load_c('aw.m') 
AW_correctionsi=load_c('aw_Corrections.m') 

## #Röttgers, R. McKee, D, and Utschig, C, "Temperature and salinity correction coefficients for light absorption by water in the visible to infrared spectral region", Opt. Express, 2014			
# Data of the salinity and temperture correction coefficients for the light absorption coefficent of water			
aw_corrections=interp1(AW_correctionsi[0],AW_correctionsi[1:],wlB) # column 0 and columns 1,2,3
## Xiaodong Zhang, Lianbo Hu, and Ming-Xia He (2009), Scatteirng by pure
# seawater: Effect of salinity, Optics Express, Vol. 17, No. 7, 5698-5710 
_, _, bsw = betasw_ZHH2009(wlB,Tc,sza,Salinty)
bbsw=0.5*bsw

##########################################################################

aw0=interp1(AWi[0],[AWi[1]],wlB)[0]
aw=aw0+(Tc-20)*aw_corrections[2]+Salinty*aw_corrections[0]

Rrs = [None] * nr_Spectra
R = [None] * nr_Spectra
Kd = [None] * nr_Spectra
IOP = [None] * nr_Spectra

lb= [1e-5,  1e-05, 1e-05, 1e-05,   1e-05]
ub= [0.65 ,  5,  0.35 , 0.025,    1.7]
#plt.ion()
#plt.show()
for ispectra in range(0,nr_Spectra):
    obsR=Measured_Rrs[ispectra]
    # approx the phytoplankton absorption-coefficent at 440nm (Lee et al., 1998)
    dummy=0.072*(obsR[indx_440]/obsR[indx_550])**-1.62 
    #
    a_chla = Coef_chla*dummy
    a_dg = Coef_dom*dummy 
    bb_SPM = Coef_spm*9.324*obsR[indx_640]  #combination of particles backscattering coefficient + viewing angle + sea state,at 400nm , Lee et al. 1999.
    Y = abs(Coef_y*3.44*(1-3.17*exp(-2.01*obsR[indx_440]/obsR[indx_490])))  #Y is between the range 0 - 2.5, Lee at al. 1996
    #>>#initialization

    IOP0=np.array([a_chla,a_dg,bb_SPM,s,Y]) # [float,float,float,float,float]
   # print('sample', ispectra, 'of', nr_Spectra)
    Rrs[ispectra],R[ispectra], Kd[ispectra], IOP[ispectra] = inversion_2SeaColor(obsR,IOP0,lb,ub,eta0,ingamma,fsky,ta_w,tw_a, wlB,sza_w ,Q,nw,z,Aa,aw,bbsw)
    #plot(wlB, obsR,'g',wlB, Rrs[ispectra],'k')
    # plt.clf()
    # plt.plot(wlB, obsR, 'g')
    # plt.plot(wlB, Rrs[ispectra],'k')
    # plt.draw()
    # plt.pause(0.001)
    #plt.show(block=False)

## this is for checking 
iop_r=load_c('IOP_IOCCG.m')
iopreal=[]
iopreal.append(iop_r[1])
iopreal.append(iop_r[2]+iop_r[3])
iopreal.append(iop_r[4]+iop_r[5])
iopreal.append(iop_r[1]+iop_r[2]+iop_r[3])
IOP=np.array(IOP)
IOP=IOP.T # transpose
iopd=[]
iopd.append(IOP[0])
iopd.append(IOP[1])
iopd.append(IOP[2])
iopd.append(IOP[0]+IOP[1])
plot_hydroFit(iopreal,iopd,[1e-5, 1e-5, 1e-5, 1e-5],[ 100, 100, 100, 100])
stop = timeit.default_timer()
execution_time = stop - start

print("Program Executed in "+str(execution_time)) # It returns time in seconds