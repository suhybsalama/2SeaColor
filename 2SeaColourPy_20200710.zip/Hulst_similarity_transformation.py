# Created by Suhyb Salama 19-09-2013 @ITC, based on the Memo of Wout Verhoef:

# ||||||||||||||||||||||||||||||||||||||||||||||||
#  similarity transformation (Van de Hulst, 1980)|
# ||||||||||||||||||||||||||||||||||||||||||||||||

import numpy as np

# input: 
#b:     backscattering coefficient
#eta:   backscattering  fraction
#a:     absorption coefficient
#gamma:  peaked fraction of the forward sacttering
#varargin: optional variable, if provided it contains the value down welling %irradiance in w/m2 otherwise it is set to unity
#------------------------------------------------------------------
# outputs:
#c_p: transformed beam attenuation coefficent (c=a+b)
#omega_p: transformed single scattering albedo (b/c)
#eta_p: transformed backscattering fraction (bb/b)
#------------------------------------------------------------------

# call:
# [c_p,omega_p,eta_p]=Hulst_similarity_transformation(a,b,eta,gamma)
#------------------------------------------------------------------
#[c_p,omega_p,eta_p,bb_p,bf_p,a_p]

# a: array<float>, b: array<float>, eta: float, bb: array<float>, gamma: float
# returns array<float>, array<float>, float

def Hulst_similarity_transformation(a,b,eta,bb,gamma):
    bf=b*(1-eta)
    bf_peak=gamma*bf
    bf_n=bf-bf_peak
    b_n=bf_n+bb
    eta_n=np.mean(bb/b_n)

## this is not wroking properly 
#c=a+b;
#omega=b./c;

#c_n1=(1-gamma.*(1-eta).*omega).*c;
#omega_n1=omega.*(1-gamma*(1-eta))./(1-gamma.*omega.*(1-eta));

#eta_n1=eta./(1-gamma.*(1-eta));
 
#bb_n1=eta_n1.*omega_n1.*c_n1;
#bf_n1=(1-eta_n1).*omega_n1.*c_n1;
#b_n1=bb_n1+bf_n1;
#a_n1=(1-omega_n1).*c_n1;

    return b_n, bf_n, eta_n

