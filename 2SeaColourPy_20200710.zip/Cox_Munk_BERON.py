# created by Suhyb Salama March 2020
# JOURNAL OF GEOPHYSICAL RESEARCH, VOL. 111, C06005, doi:10.1029/2005JC003343, 2006
import numpy as np
from math import pi
from wave_slope_prob import wave_slope_prob
from Snells_Law import Snells_Law
from Fresnel import Fresnel


def Cox_Munk_BERON(ws,phi_w,sza,vza,saa,vaa,ni,nt):
    phi=saa-vaa
    Zx=-(np.sin(sza)+np.sin(vza)*np.cos(phi))/(np.cos(sza)+np.cos(vza))
    Zy=-(np.sin(vza)*np.sin(phi))/(np.cos(sza)+np.cos(vza))
    Beta=np.arctan(np.sqrt(Zx**2+Zy**2))
    Zup=Zx*np.cos(phi_w)+Zy*np.sin(phi_w)
    Zcr=Zy*np.cos(phi_w)-Zx*np.sin(phi_w)

    p=wave_slope_prob(ws,Zup,Zcr)

    theta_i=0.5*np.arccos(np.cos(sza)*np.cos(vza)+np.sin(sza)*np.sin(vza)*np.cos(phi))
    theta_t=Snells_Law(theta_i,ni,nt)
    r=Fresnel(theta_i,theta_t,ni,nt)

    # rho is in reflectance
    rho=pi*r/(4*np.cos(vza)*np.cos(sza)*np.cos(Beta)**4)*p
    rho=np.minimum(1,rho)
    return rho, Zx, p
