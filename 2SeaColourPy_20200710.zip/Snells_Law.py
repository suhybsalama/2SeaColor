import numpy as np

# ai: float, ni: array<float>, nt: array<float>
# returns array<float>

def Snells_Law(ai,ni,nt):
    
    sinat = ni/nt*np.sin(ai)
    sinat = np.minimum(1,sinat)
    at = np.arcsin(sinat)

    return at
