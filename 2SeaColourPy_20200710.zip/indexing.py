#created by Suhyb Salama 2018

import numpy as np

# A: array<float>, B: array<float>
# return array<float>

def indexing(A,B):
    LB=len(B)
    LA=len(A)

    large=LB
    small=LA
    if LB<LA:
        large=LA
        small=LB
        dump=A
        A=B
        B=dump

    count=0
    I = np.array([], dtype=int)
    for j in range(0, small):
        m,ii=min([(abs(A[j] - x),i) for (x,i) in zip(B,range(0,len(B)))])
        I = np.append(I, ii+count)
        if len(B)>1:
            B = np.delete(B, ii)
            count=count+1
        else:
            j=small

    return I
