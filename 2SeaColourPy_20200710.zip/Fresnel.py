# Created by Suhyb Salama 2015

import numpy as np

# ai: float, at: float, ni: array<float>, nt: array<float>
# returns array<float>

def Fresnel(ai,at,ni,nt):
    rh=(ni*np.cos(ai)-nt*np.cos(at))/(ni*np.cos(ai)+nt*np.cos(at))
    rv=(ni*np.cos(at)-nt*np.cos(ai))/(ni*np.cos(at)+nt*np.cos(ai))
    r=0.5*(rv**2+rh**2)
    return r



