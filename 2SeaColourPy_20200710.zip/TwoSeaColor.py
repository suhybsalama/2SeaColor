#Created by Suhyb Salama* 30-03-2014 @ITC, based on the RSE submitted
#paper:
#Two-Stream Color Model for Water Quality in Inland Lakes: 2SeaColor
# 
# Mhd. Suhyb Salama and Wouter Verhoef
# 
# University of Twente, Faculty of Geo-Information Science and Earth Observation (ITC), 
# Department of Water Resources, 
# P.O. Box 217, 7500 AE Enschede, The Netherlands
# # 
# 
# 
# 
# *Corresponding author: +31534874288; s.salama@utwente.nl
##||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

import numpy as np

## input: 
#a: total absorption
#bb: total backscattering
#b:scattering 
#eta: fraction of backscattering
#gamma: fraction of peaked sorward scattering
#fsky: fraction of diffuse sky
#theta: sun zenith
#z depth
#varargin: other vars

## Outputs:
#Kd at diffrenbt depths
#R: irradiance ref at -0
#Rrs: at +0
##

def TwoSeaColor(a,bb,b,fsky,theta_w,z,Q,ta_w,tw_a,nw):
    Es=1  
    mu=np.cos(theta_w)
    ##---------
    bf=b-bb
    ##
    #--------------------------------------------------
    k=(a+b)/mu # attenuation of direct light for downward flux
    kappa=2*(a+b)
    # Direct light ## old version
    sp=bf/mu #forward scattering of direct light for downward flux
    s=bb/mu #backward scattering of the direct light
    sig=2*bb # backscattering of diffuse light
    sigp=2*bf
    #------------------------------------------------------------

    # 
    #  ## --------------------------------------------------------------------
    alfa=kappa-sigp
    m=np.sqrt(alfa**2-sig**2) #the coefficient in the deferential solution 
    ##

    rdd=sig/(alfa+m) #infinite reflectance of the medium, i.e. the bi-hemispherical reflectance for infinite optical thickness
    #rdd=(alfa-m)/sig #infinite reflectance of the medium, i.e. the bi-hemispherical reflectance for infinite optical thickness

    rsd=(s+sp*rdd)/(k+m) #the infinite directional-hemispherical reflectance factor for direct sunlight (DHRF) downward

    J=(np.exp(m*z)-np.exp(k*z))/(k-m) #
    if (abs(k-m) < 1e-3).all():
        J=-z*np.exp(k*z) #

    #-----------------------------------------------------------------

    ## irradiances
    Eds0=(1-fsky)*Es #direct sun flux
    Edd0=fsky*Es #diffuse sun flux
    Eds=Eds0*np.exp(z*k) #down welling direct irradiance
    Edd=Edd0*np.exp(z*m)+(sp+sig*rsd)*J*Eds0 ##down welling diffuse irradiance
 
    Eu=rdd*Edd+rsd*Eds ##total upwelling irradiance

    Ed=Edd+Eds ###total down welling irradiance
 
    ## Attenuation Coefficients of downward light

    Kd=((k-sp)*Eds+alfa*Edd-sig*Eu)/Ed
    ##
  
    Rw=Eu/Ed #beneath the surface water irradiance reflectance

    #----------------------------------------------------------------

    rrs=Rw/Q
    rw_a=1-tw_a
    Rrs=ta_w*tw_a*rrs/(nw**2*(1-rw_a*Rw))
    
    return Kd, Rw, Rrs
