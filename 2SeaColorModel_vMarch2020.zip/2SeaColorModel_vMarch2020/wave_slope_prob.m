%created by Suhyb Salama 2020 
% after  Breon and Henriot (2006) JOURNAL OF GEOPHYSICAL RESEARCH, VOL. 111, C06005, doi:10.1029/2005JC003343, 2006

function p=wave_slope_prob(ws,Zup,Zcr)

sigma2_up=1e-3+3.16e-3.*ws;
sigma_up=sqrt(sigma2_up);

sigma2_cr=3e-3+1.85e-3.*ws;
sigma_cr=sqrt(sigma2_cr);

c21=-9e-4.*ws.^2;

c03=-0.45.*(1+exp(7-ws))^(-1);
c40=0.3;
c04=0.4;
c22=0.12;
eta=Zup./sigma_up;
psi=Zcr./sigma_cr;


p=1./(2*pi.*sigma_up.*sigma_cr).*exp(-0.5.*(psi.^2+eta.^2)).*(...
   1-1/2.*c21.*(psi.^2-1).*eta...
    -1/6.*c03.*(eta.^3-3*eta)...
    +1/24.*c40.*(psi.^4-6.*psi.^2+3)...
    +1/24.*c04.*(eta.^4-6.*eta.^2+3)...
    +1/4*c22.*(psi.^2-1).*(eta.^2-1));
end