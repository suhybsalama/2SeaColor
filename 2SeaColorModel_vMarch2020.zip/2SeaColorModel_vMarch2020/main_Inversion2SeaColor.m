%% main
%%Created by Suhyb Salama @ITC 2015
%%Salama, M. S., & Verhoef, W. (2015). 
%%Two-stream remote sensing model for water quality mapping: 2SeaColor.
%%Remote sensing of environment, 157, 111-122. https://doi.org/10.1016/j.rse.2014.07.022

%% updated 10 of March 2020 for EO4SD-Coastal project

clear all
%image read
z=[0];
sza=30;% Solar viweing angle: read from the image
vza=42;  % Viewing zenith angle: read from the iamge
saa=0; %Solar azimuth : read from the image
vaa=90; %Viewing azimuth : read from the iamge
phi=vaa-saa; %

Rrs_Data_file='Rrs_hydrolight.m'; %read from the imgae   
Spectra = load( Rrs_Data_file);%read from the imgae 
wlB=Spectra(1,:)';%L=[443,490,560,665,705,740,783,842,865]; %S2 wavelength
Measured_Rrs=Spectra(2:end,:)';

%#############################################################
nr_Spectra=length(Measured_Rrs);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Water input
Tc=25;% water tempreture 
Q=3.25;% istropic factor
Salinty=30;
ws=5;%Wind speed
phi_w=15;% wind direction if possible read

 [nw, na]= RIaw(wlB,Tc,Salinty);   
%%
    ra_w=Cox_Munk_BERON(ws,phi_w,sza,vza,saa,vaa,na,nw);
    ta_w=1-ra_w;
    
    vza_w=rad2deg(Snells_Law(deg2rad(vza),na,nw));
    sza_w=rad2deg(Snells_Law(deg2rad(sza),na,nw));
      rw_a=Cox_Munk_BERON(ws,vza_w,90-vza,saa,vaa,nw,na,1);
    tw_a=1-rw_a;


%%
 Coef_chla=0.02;
Coef_dom=0.015;
Coef_spm=0.018;
Coef_y=0.5;
Coef_s=0.002; 
    
  

L_needed=[443,490,560,665];
indx_=indexing(L_needed,wlB);
indx_440=indx_(1);
indx_490=indx_(2);
indx_550=indx_(3);
if length(indx_)>3
indx_640=indx_(4);
end
eta0=0.0182;
s=0.021;
ingamma=0.80;
fsky=0.5;
%%
AWi=load('aw.m');
AW_correctionsi=load('aw_Corrections.m');
 Aa=load('A_mod.m');
%% %R�ttgers, R. McKee, D, and Utschig, C, "Temperature and salinity correction coefficients for light absorption by water in the visible to infrared spectral region", Opt. Express, 2014			
% Data of the salinity and temperture correction coefficients for the light absorption coefficent of water			
aw_corrections=interp1(AW_correctionsi(:,1),AW_correctionsi(:,2:end),wlB);
%% Xiaodong Zhang, Lianbo Hu, and Ming-Xia He (2009), Scatteirng by pure
% seawater: Effect of salinity, Optics Express, Vol. 17, No. 7, 5698-5710 
[~,~,bsw]= betasw_ZHH2009(wlB,Tc,sza,Salinty);
bbsw=0.5.*bsw;
%#########################################################################
aw0=interp1(AWi(:,1),AWi(:,2),wlB);
aw=aw0+(Tc-20).*aw_corrections(:,3)+Salinty.*aw_corrections(:,1); 

lb=  [1e-5,  1e-5, 1e-5, 0.0085,     0.1];
ub= [2.5 ,  2.5,  2.5 , 0.025,    1.7];
for ispectra=1:nr_Spectra
    obsR=Measured_Rrs(:,ispectra)';
    % approx the phytoplankton absorption-coefficent at 440nm (Lee et al., 1998)
      dummy=0.072*(obsR(indx_440)./obsR(indx_550)).^-1.62;
%
a_chla = Coef_chla*dummy; 

a_dg = Coef_dom*dummy;
bb_SPM =Coef_spm*9.324*obsR(indx_640); %combination of particles backscattering coefficient + viewing angle + sea state,at 400nm , Lee et al. 1999.
Y = abs(Coef_y*3.44*(1-3.17*exp(-2.01*obsR(indx_440)/obsR(indx_490)))); %Y is between the range 0 - 2.5, Lee at al. 1996
%>>%initialization

IOP0=[a_chla,a_dg,bb_SPM,s,Y];
[Rrs(ispectra,:),R(ispectra,:), Kd(ispectra,:), IOP(:,ispectra)] = inversion_2SeaColor(obsR,IOP0,lb,ub,eta0,ingamma,fsky,ta_w,tw_a, ...
    wlB,sza_w ,Q,nw,z,Aa,aw,bbsw);

plot(wlB, obsR,'g',wlB, Rrs(ispectra,:),'k');
drawnow
end
%% this is for checking 
iop_r=load('IOP_IOCCG.m');
iopreal=zeros(500,4);
iopreal(:,1)=iop_r(:,2);
iopreal(:,2)=iop_r(:,3)+iop_r(:,4);
iopreal(:,3)=iop_r(:,5)+iop_r(:,6);
iopreal(:,4)=iop_r(:,2)+iop_r(:,3)+iop_r(:,4);
iopd=iopreal;
iopd(:,1:3)=IOP(1:3,:)';
iopd(:,4)=IOP(2,:)'+IOP(1,:)';
plot_hydroFit((iopreal),(iopd),([1e-5 , 1e-5 1e-5 1e-5]),([ 100 100 100 100]))
