%created by Suhyb Salama 2008
% from Salama et al (2009) and Salama and Stein 2009
% new update in 2016
function [a bb]= IOP_parametrization(IOP0,wlB, Aa,aw,bbsw)
           
        achl440 = IOP0(1);
        adg440   = IOP0(2);
        bbspm440 = IOP0(3);
        s         = IOP0(4);
        y         = IOP0(5);   

[n m]=size(wlB);
if n<m
 wlB=wlB';   
 n=m;
end
wlB=double(wlB);
%m=length(C_chla);
a_dg =adg440*exp(-s*(wlB' - 440.00));
%% PAAVEL et al., (2016)	
% SIOP_chlai=load('SIOP_chla.m');
% SIOP_chla=interp1(SIOP_chlai(:,1),SIOP_chlai(:,2:end),lambda);
% A=SIOP_chla(:,1);
% B=SIOP_chla(:,2);
%a_chla=repmat(A,1,m)'.*repmat(C_chla,1,n).^(1-repmat(B,1,m)');
%% Lee parameterization

 A=interp1(Aa(:,1),Aa(:,2:end),wlB);
 a1=A(:,1);
 a2=A(:,2);
 a_chla=(repmat(a1,1,m)'+log(repmat(achl440,1,n)).*repmat(a2,1,m)').*repmat(achl440,1,n);
%%



 
a = repmat(aw,1,m)' +a_dg+a_chla;% bulk absorption coefficient.



bb_spm=bbspm440*(440./wlB').^y;

 bb = repmat(bbsw,m,1)+ bb_spm; % bulk scattering coefficient. 
end

