%% Created by Suhyb salama @ ITC 2015
function [m,b,R,RMSE,bias,MAPE,rMAD]=plot_hydroFit(measured,derived,lb,ub);

clc

eps=0.1;
figNr=4;
bdwidth = 30;
topbdwidth = 150;
set(0,'Units','pixels') 
scnsize = get(0,'ScreenSize');
pos1  = [bdwidth,... 
	+ bdwidth,...
	scnsize(3) - 6*bdwidth,...
	scnsize(4) - (topbdwidth + bdwidth)];

figure('Position',pos1) 


%these value are for sub figures in the fig its self
wh=[0.36,0.36];
up=[0.1, 0.6];
ur=[0.55, 0.6];
ll=[0.1, 0.1];
lr=[0.55, 0.1];
corner=[up;ur;ll;lr];


for i=1:figNr
h(i)= subplot(2,2,i);
pos(i,:)=[corner(i,:),wh];
end

label={'  a_{chla}(440) [m^{-1}]';'  a_{dg}(440) [m^{-1}]';'  b_{b,spm} [m^{-1}]';...
    '  a(440) [m^{-1}]'};

titel=[{'(a)'};...
     {'(b)'};...
     {'(c)'};...
     {'(d)'}];
 
     xshift=0;
yshift=40;

[num_site var_nr ]=size(measured);


for i=1:var_nr
  
     index=find(derived(:,i)>lb(i)&derived(:,i)<=ub(i));    
      real_site_nr=length(index);
      
      f=ceil(real_site_nr./num_site*100)/100;
    
    iop_d=(derived(index,i));
    iop_m=(measured(index,i));
    

   

  
     [m(i),b(i),rd(i),sm(i),sb(i)]=lsqfitgm(iop_m,iop_d);  
    
    
    R(i)=ceil((rd(i)^2)*100)./100;
    dump=iop_d- iop_m;
    range=max(iop_m)-min(iop_m);%std(iop_m);%
    MAPE(i)=100*mean(abs(dump)./iop_m);
    rMAD(i)=100*mean(abs(dump)./range);
    
    MAD(i)= sum(abs(dump)./(real_site_nr-2));
    RMSE(i)=sqrt(sum(dump.^2)./(real_site_nr-2));
    
bias(i)=(mean(iop_m-iop_d));

  
  subplot(2,2,i);
  xmin=min([iop_d' iop_m']);
  xmax=max([iop_d' iop_m']);
  step=abs(xmax-xmin)./100;

     xshift=95;
yshift=21;  



box on,axis('square');
        axis([xmin,xmax,xmin,xmax]);

  plot(iop_m,iop_d,'MarkerFaceColor',[0.502 0.502 0.502],...
    'Marker','o',...
    'LineStyle','none',...
    'Color',[0.502 0.502 0.502]);
    
 hold on 
   box on,axis('square');
        axis([xmin,xmax,xmin,xmax]);
        h=refline(1,0); set(h,'Color',[0 0 0]);
        
set(gca,'FontSize',12);
xtxt=[strcat('known  ', '  ',label(i)) ];
xlabel(xtxt);
ytxt=[strcat('Derived  ',' ', label(i)) ];
ylabel(ytxt)
str=['fr=' num2str(f)];
text(xmax-xshift*step,xmin+2.5*yshift*step,str,'FontSize',12); 

str=['rMAD=' num2str(rMAD(i)) '[%]'];
str=['MAPE=' num2str(MAPE(i)) '[%]'];

str=['MAD=' num2str(round(MAD(i),2)) ' [m^{-1}]'];
%str=['RMSE=' num2str(RMSE(i)) ' [m^{-1}]'];
text(xmax-xshift*step,xmin+3*yshift*step,str,'FontSize',12); 

str=['R^2=' num2str(R(i))];
text(xmax-xshift*step,xmin+3.5*yshift*step,str,'FontSize',12); 

str=['Offset =' num2str(round(b(i),2))];
text(xmax-xshift*step,xmin+4*yshift*step,str,'FontSize',12);

str=['Slope =' num2str(round(m(i),2))];
text(xmax-xshift*step,xmin+4.5*yshift*step,str,'FontSize',12); 

set(gca,'Position',pos(i,:),...
    'CameraViewAngleMode','Manual','DataAspectRatioMode',...
    'Manual', 'PlotBoxAspectRatioMode','Manual','XMinorTick','on','YMinorTick','on','Title',text('String',[titel(i)]...
         ,'FontSize',12))
end
end%function