%create dby Suhyb Salama March 2020
%JOURNAL OF GEOPHYSICAL RESEARCH, VOL. 111, C06005, doi:10.1029/2005JC003343, 2006
function [rho Zx p]=Cox_Munk_BERON(ws,phi_wind,sza0,vza0,saa0,vaa0,ni,nt)

sza=deg2rad(sza0);
phi_w=deg2rad(phi_wind);
vza=deg2rad(vza0);
saa=deg2rad(saa0);
vaa=deg2rad(vaa0);
phi=saa-vaa;

Zx=-(sin(sza)+sin(vza).*cos(phi))./(cos(sza)+cos(vza));
Zy=-(sin(vza).*sin(phi))./(cos(sza)+cos(vza));
Beta=atan(sqrt(Zx.^2+Zy.^2));
Zup=Zx.*cos(phi_w)+Zy.*sin(phi_w);
Zcr=Zy.*cos(phi_w)-Zx.*sin(phi_w);

p=wave_slope_prob(ws,Zup,Zcr);

theta_i=0.5*acos(cos(sza)*cos(vza)+sin(sza)*sin(vza)*cos(phi));



theta_t=Snells_Law(theta_i,ni,nt);
[r]= Fresnel(theta_i,theta_t,ni,nt);

%rho is in reflectance
rho=pi.*r./(4*cos(vza)*cos(sza).*cos(Beta).^4).*p;
rho(rho>1)=1;
    
rho=reshape(real(rho),1,length(rho));
end