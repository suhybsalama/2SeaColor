function [at]=Snells_Law(ai,ni,nt)

    sinat=ni./nt.*sin(ai);
    sinat(find(sinat>1))=1;
    at=asin(sinat);
at=reshape(at,1,length(at));
end