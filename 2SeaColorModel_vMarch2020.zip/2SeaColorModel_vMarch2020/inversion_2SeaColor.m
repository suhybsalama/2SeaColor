%created by Suhyb Salama March 2020
%this is an update of the old version in 2015
function [Rrs,R, Kd, IOP] = inversion_2SeaColor(obsR,IOP0,lb,ub,eta0,ingamma,fsky,ta_w,tw_a, ...
    wlB,sza_w ,Q,nw,z,A,aw,bbsw)

ed=1;

options1 = optimoptions('lsqnonlin','Algorithm','trust-region-reflective','TolFun',1e-6,'MaxFunEvals',10000,'MaxIter',10000);


 [IOP ]=lsqnonlin(@computeR,IOP0,lb,ub,options1);
     function Rdiff = computeR(IOP0)%,ed)
         
           [aa,bb]= IOP_parametrization(IOP0,wlB, A,aw,bbsw);
          
         
            b=bb./eta0;
          
            [b,~, eta]= Hulst_similarity_transformation(aa,b,eta0,bb,ingamma);
               %bb=eta.*b; No change in bb
            
            [Kd, R, Rrs]=TwoSeaColor(aa,bb,b,fsky,sza_w,z,Q,ta_w,tw_a,nw);
                          
            Rdiff=Rrs-obsR;
      
    end  

end
