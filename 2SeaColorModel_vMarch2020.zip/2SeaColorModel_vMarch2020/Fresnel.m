%Created by Suhyb Salama 2015
function [r]=Fresnel(ai,at,ni,nt)


    rh=(ni.*cos(ai)-nt.*cos(at))./...
    (ni.*cos(ai)+nt.*cos(at));

rv=(ni.*cos(at)-nt.*cos(ai))./...
    (ni.*cos(at)+nt.*cos(ai));
r=0.5.*(rv.^2+rh.^2);



end


