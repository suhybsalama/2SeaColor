%Created by Suhyb Salama 30-12-2013 @ITC

%inversion of Duntley without parMETRIZATION
%------------------------------------------------------------------

%%
function Rrs =setup2SeaColor_NO_PARAMETRIZATION(X_var,XX)

  global z bbFrac theta a_final bb_final eta_final b_final Rrs_final Q_final ;
  


szap=asin(3*sind(theta)/4);%Under water sun zenith using Snell�s law
    mu=cos(szap);
   
abs_Lambda_ref=490;
scat_Lambda_ref=490;
Lw = XX(:,1); % the wavelength 390-720nm at 10nm interval. 
aw=XX(:,2);
Measured_Rrs=XX(:,3);
gamma=mean(XX(:,4));
fsky=mean(XX(:,5));
Es=1;


SPM_scat=X_var(1);
Ys=X_var(2);
Ys2=X_var(3);


bw=(0.0076*(400./Lw).^4.312);%adapted equation from hydrolight data
bsp = SPM_scat*(scat_Lambda_ref./Lw).^(Ys); % particles scattering coefficient.
nir_b=Lw(end)-20:1:Lw(end);
[~, nir]=my_find(Lw,nir_b);
 rrs=Measured_Rrs./(0.52+1.7*Measured_Rrs);
%% inversion based on Lee:::::::::::::::::::::::::::::::::
% g0=0.089;
% g1=0.125;
% u= (-g0+sqrt(g0.^2+4.*g1.*rrs))./(2*g1);
% bb_spm_small_nir=u(nir).*aw(nir)./(1-u(nir))-0.5*bw(nir);
%::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

%% simple inversion based on 2seacolro rsd:::::::::::::::::::

rsd=Q_final.*rrs;

 meta=(1-bbFrac)./bbFrac;
  y=(meta+2.*rsd.*mu+sqrt((meta+2*rsd*mu).^2-(1-rsd).*(meta+1).*(1+rsd).*(meta-1)))...
      ./((1-rsd).*(meta+1));
 x=(y.^2-1)./2;
 
 bb_spm_small_nir=x(nir).*aw(nir)-0.5*bw(nir);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

bb_small=mean(bb_spm_small_nir).*(mean(Lw(nir))./Lw).^(Ys2);
bsp(nir)=0;
bb = 0.5.*bw+ bbFrac*bsp+bb_small; % bulk scattering coefficient. 

a_cons=bb./x-aw;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%a_cons=bb.*(1-u)./u-aw;



a_cons(nir)=0;
index=find(a_cons <0);
a_cons(index)=0;
a=a_cons+aw;

b=bw+bsp+bb_small./bbFrac;
eta=mean(bb./b);

%  plot(Lw,a,'k',Lw,aw,'^r')
%  drawnow
%%

transform=0;
   
[~, ~,Rrs, Q, eta_final(1,:)]=TwoSeaColor(a,bb,b,eta,gamma,fsky,theta,z(1),transform);
for k=2:length(z)
[~,~,~,~,eta_final(k,:)]=TwoSeaColor(a,bb,b,eta,gamma,fsky,theta,z(k),transform);    
end
a_final=a;
bb_final=bb;
b_final=b;
Q_final=Q;
Rrs_final=Rrs;                  

% 

      
end
 
 



