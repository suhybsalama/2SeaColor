function [m,b,R,MAD]=plot_Fit(measured,derived,para,depth, refLambda,unit);
[nn mm]=size(measured);

if nn <mm 
    measured=measured';
end
[nn mm]=size(derived);

if nn <mm 
    derived=derived';
end

if length(refLambda) ==1
    refLambda=repmat(refLambda,4,1);
end
titel_tex='Depth';
unit_titel= ' m)';
if strcmp(unit,'%') || strcmp(unit,'sr^{-1}') 
    titel_tex='\lambda';
    depth= refLambda;
    unit_titel=' nm)';
end


switch  (para)
    case 'R'
                titel_tex='R(\lambda';
unit_titel= ' nm)';
    case 'Rrs'
        titel_tex='Rrs(\lambda';
unit_titel= ' nm)';
    case 'Kd'
        titel_tex='Kd(490,z';
unit_titel= ' m)';
    case 'Q'    
    titel_tex='Q(\lambda';
    depth= refLambda;
    unit_titel=' nm)';
    case 'a'    
    titel_tex='a(';
    depth= refLambda;
    unit_titel=' m^{-1})';
    case 'bb'
       titel_tex='bb(';
    depth= refLambda;
    unit_titel=' m^{-1})';
end

used_para=depth;
p=length(depth);

 pp=length(refLambda) ;
    figNr=4;%max(p,pp);
    if pp >p 
        used_para=refLambda;
    end
ti=['a', 'b', 'c', 'd'];
%ti=ti(1:figNr);
for i=1:figNr

label(i)={[ para ' (' num2str(refLambda(i)) ') '  unit]};...


titel(i)={['(' ti(i) ', ' titel_tex '=' num2str(used_para(i)) unit_titel]};...
   
end

bdwidth = 30;
topbdwidth = 150;
set(0,'Units','pixels') 
scnsize = get(0,'ScreenSize');
pos1  = [bdwidth,... 
	+ bdwidth,...
	scnsize(3) - 6*bdwidth,...
	scnsize(4) - (topbdwidth + bdwidth)];

figure('Position',pos1) 


%these value are for sub figures in the fig its self
wh=[0.36,0.36];
up=[0.1, 0.6];
ur=[0.55, 0.6];
ll=[0.1, 0.1];
lr=[0.55, 0.1];
corner=[up;ur;ll;lr];

NR_subplot=ceil(figNr./2);
     xshift=0;
yshift=40;
%%
for i=1:figNr
h(i)= subplot(2,NR_subplot,i);
pos(i,:)=[corner(i,:),wh];


     [m(i),b(i),rd(i),sm(i),sb(i)]=lsqfitgm(measured(:,i),derived(:,i));  
    
    Range=(max(measured(:,i))-min(measured(:,i)));
    R(i)=ceil((rd(i).^2)*1000)./1000;
    
       diff=abs(measured(:,i)-derived(:,i)) ;
    b(i)=ceil(b(i)*100)./100;
    m(i)=ceil(m(i)*100)./100;
  %MAD(i)=100*mean(diff./measured(:,i)));   
 MAD(i)=100*mean(diff./Range);
    MAD(i)=ceil(MAD(i)*100)./100;

sigm=smooth(diff,0.1,'rloess');

   
  subplot(2,NR_subplot,i);
  xmin=min([measured(:,i)' derived(:,i)']);
  xmax=max([measured(:,i)' derived(:,i)']);
  
  step=abs(xmax-xmin)./100;

     xshift=95;
yshift=21;  



box on,axis('square');
        axis([xmin,xmax,xmin,xmax]);

  plot(measured(:,i),derived(:,i),'MarkerFaceColor',[0.502 0.502 0.502],...
    'Marker','o',...
    'LineStyle','none',...
    'Color',[0.502 0.502 0.502]);

    
 hold on 
   box on,axis('square');
        axis([xmin,xmax,xmin,xmax]);
        h=refline(1,0); set(h,'Color',[0 0 0]);
      
set(gca,'FontSize',12);
xtxt=[strcat('known  ', '  ',label(i)) ];
xlabel(xtxt);
ytxt=[strcat('Derived  ',' ', label(i)) ];
ylabel(ytxt)

str=['Slope=' num2str(m(i))];
text(xmax-xshift*step,xmin+3*yshift*step,str,'FontSize',12); 

str=['Intercept=' num2str(b(i))];
text(xmax-xshift*step,xmin+3.5*yshift*step,str,'FontSize',12); 
str=['rMAD=' num2str(MAD(i))];
text(xmax-xshift*step,xmin+4*yshift*step,str,'FontSize',12); 
str=['R^2=' num2str(R(i))];

text(xmax-xshift*step,xmin+4.5*yshift*step,str,'FontSize',12); 
set(gca,'Position',pos(i,:),...
    'CameraViewAngleMode','Manual','DataAspectRatioMode',...
    'Manual', 'PlotBoxAspectRatioMode','Manual','XMinorTick','on','YMinorTick','on','Title',text('String',titel(i)...
         ,'FontSize',12))
     end
end
